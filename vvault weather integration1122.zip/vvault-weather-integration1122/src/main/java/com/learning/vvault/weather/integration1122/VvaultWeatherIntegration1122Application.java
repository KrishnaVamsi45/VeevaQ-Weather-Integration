package com.learning.vvault.weather.integration1122;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VvaultWeatherIntegration1122Application {

	public static void main(String[] args) {
		SpringApplication.run(VvaultWeatherIntegration1122Application.class, args);
	}

}
