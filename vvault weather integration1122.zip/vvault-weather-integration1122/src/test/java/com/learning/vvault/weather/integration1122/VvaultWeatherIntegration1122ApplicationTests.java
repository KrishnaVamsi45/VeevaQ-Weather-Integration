package com.learning.vvault.weather.integration1122;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VvaultWeatherIntegration1122ApplicationTests {

	@Test
	void contextLoads() {
	}

}
